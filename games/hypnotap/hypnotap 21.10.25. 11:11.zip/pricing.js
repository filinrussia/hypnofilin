// Конфигурация продуктов и цен
const pricingConfig = {
    // Идентификаторы продуктов для App Store / Google Play
    productIds: {
        monthly: 'com.hypnotap.emdr.monthly',
        quarterly: 'com.hypnotap.emdr.quarterly',
        annual: 'com.hypnotap.emdr.annual'
    },
    
    // Цены по регионам (валюта автоматически определяется по языку)
    // Эти цены показываются до загрузки из стора
    prices: {
        // Россия (рубли)
        ru: {
            monthly: {
                price: 490,
                currency: '₽',
                formatted: '₽490',
                perMonth: '₽490'
            },
            quarterly: {
                price: 990,
                currency: '₽',
                formatted: '₽990',
                perMonth: '₽330',
                savePercent: 30
            },
            annual: {
                price: 2990,
                currency: '₽',
                formatted: '₽2990',
                perMonth: '₽249',
                savePercent: 50
            }
        },
        
        // США (доллары)
        en: {
            monthly: {
                price: 4.99,
                currency: '$',
                formatted: '$4.99',
                perMonth: '$4.99'
            },
            quarterly: {
                price: 9.99,
                currency: '$',
                formatted: '$9.99',
                perMonth: '$3.33',
                savePercent: 30
            },
            annual: {
                price: 29.99,
                currency: '$',
                formatted: '$29.99',
                perMonth: '$2.49',
                savePercent: 50
            }
        },
        
        // Европа (евро)
        de: {
            monthly: {
                price: 4.99,
                currency: '€',
                formatted: '4,99 €',
                perMonth: '4,99 €'
            },
            quarterly: {
                price: 9.99,
                currency: '€',
                formatted: '9,99 €',
                perMonth: '3,33 €',
                savePercent: 30
            },
            annual: {
                price: 29.99,
                currency: '€',
                formatted: '29,99 €',
                perMonth: '2,49 €',
                savePercent: 50
            }
        },
        
        // Франция (евро)
        fr: {
            monthly: {
                price: 4.99,
                currency: '€',
                formatted: '4,99 €',
                perMonth: '4,99 €'
            },
            quarterly: {
                price: 9.99,
                currency: '€',
                formatted: '9,99 €',
                perMonth: '3,33 €',
                savePercent: 30
            },
            annual: {
                price: 29.99,
                currency: '€',
                formatted: '29,99 €',
                perMonth: '2,49 €',
                savePercent: 50
            }
        },
        
        // Италия (евро)
        it: {
            monthly: {
                price: 4.99,
                currency: '€',
                formatted: '4,99 €',
                perMonth: '4,99 €'
            },
            quarterly: {
                price: 9.99,
                currency: '€',
                formatted: '9,99 €',
                perMonth: '3,33 €',
                savePercent: 30
            },
            annual: {
                price: 29.99,
                currency: '€',
                formatted: '29,99 €',
                perMonth: '2,49 €',
                savePercent: 50
            }
        },
        
        // Испания (евро)
        es: {
            monthly: {
                price: 4.99,
                currency: '€',
                formatted: '4,99 €',
                perMonth: '4,99 €'
            },
            quarterly: {
                price: 9.99,
                currency: '€',
                formatted: '9,99 €',
                perMonth: '3,33 €',
                savePercent: 30
            },
            annual: {
                price: 29.99,
                currency: '€',
                formatted: '29,99 €',
                perMonth: '2,49 €',
                savePercent: 50
            }
        },
        
        // Китай (юани)
        zh: {
            monthly: {
                price: 35,
                currency: '¥',
                formatted: '¥35',
                perMonth: '¥35'
            },
            quarterly: {
                price: 68,
                currency: '¥',
                formatted: '¥68',
                perMonth: '¥23',
                savePercent: 30
            },
            annual: {
                price: 198,
                currency: '¥',
                formatted: '¥198',
                perMonth: '¥17',
                savePercent: 50
            }
        },
        
        // Бразилия (реалы)
        pt: {
            monthly: {
                price: 24.90,
                currency: 'R$',
                formatted: 'R$ 24,90',
                perMonth: 'R$ 24,90'
            },
            quarterly: {
                price: 49.90,
                currency: 'R$',
                formatted: 'R$ 49,90',
                perMonth: 'R$ 16,63',
                savePercent: 30
            },
            annual: {
                price: 149.90,
                currency: 'R$',
                formatted: 'R$ 149,90',
                perMonth: 'R$ 12,49',
                savePercent: 50
            }
        },
        
        // Южная Корея (воны)
        ko: {
            monthly: {
                price: 6500,
                currency: '₩',
                formatted: '₩6,500',
                perMonth: '₩6,500'
            },
            quarterly: {
                price: 13000,
                currency: '₩',
                formatted: '₩13,000',
                perMonth: '₩4,333',
                savePercent: 30
            },
            annual: {
                price: 39000,
                currency: '₩',
                formatted: '₩39,000',
                perMonth: '₩3,250',
                savePercent: 50
            }
        },
        
        // Япония (йены)
        ja: {
            monthly: {
                price: 700,
                currency: '¥',
                formatted: '¥700',
                perMonth: '¥700'
            },
            quarterly: {
                price: 1400,
                currency: '¥',
                formatted: '¥1,400',
                perMonth: '¥467',
                savePercent: 30
            },
            annual: {
                price: 4200,
                currency: '¥',
                formatted: '¥4,200',
                perMonth: '¥350',
                savePercent: 50
            }
        }
    },
    
    // Функция получения цен для текущего языка
    getPricing(lang) {
        // Если язык не найден, используем английский
        return this.prices[lang] || this.prices.en;
    },
    
    // Функция форматирования цены с подставновкой в строку
    formatPrice(template, price) {
        return template.replace('{price}', price);
    },
    
    // Получить информацию о плане
    getPlanInfo(lang, planType) {
        const pricing = this.getPricing(lang);
        return pricing[planType];
    }
};

// Экспортируем для использования в других файлах
// (в браузере это будет глобальная переменная)
if (typeof module !== 'undefined' && module.exports) {
    module.exports = pricingConfig;
}
